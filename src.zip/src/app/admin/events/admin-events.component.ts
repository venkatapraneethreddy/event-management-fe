import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AdminService } from '../../core/services/admin.service';
import { ToastrService } from 'ngx-toastr';
import { PaginationComponent } from '../../shared/pagination/pagination.component';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { TagModule } from 'primeng/tag';
import { TableModule } from 'primeng/table';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { SkeletonModule } from 'primeng/skeleton';
import { ChipModule } from 'primeng/chip';
import { TooltipModule } from 'primeng/tooltip';
import { AvatarModule } from 'primeng/avatar';

@Component({
  selector: 'app-admin-events',
  standalone: true,
  imports: [
    CommonModule, FormsModule, RouterModule, PaginationComponent,
    ButtonModule, InputTextModule, TagModule, TableModule,
    IconFieldModule, InputIconModule, SkeletonModule, ChipModule,
    TooltipModule, AvatarModule
  ],
  template: `
<div class="admin-events">
  <div class="page-header">
    <div>
      <h1>All Events</h1>
      <p>View and moderate all events across every club on the platform.</p>
    </div>
  </div>

  <ng-container *ngIf="loading">
    <div class="stats-row"><p-skeleton *ngFor="let i of [1,2,3,4]" height="76px" borderRadius="14px"></p-skeleton></div>
    <p-skeleton height="400px" borderRadius="14px"></p-skeleton>
  </ng-container>

  <ng-container *ngIf="!loading">
    <div class="stats-row">
      <div class="stat-card" [class.active]="statusFilter==='ALL'" (click)="statusFilter='ALL'; applyFilter()">
        <div class="stat-icon brand"><i class="pi pi-calendar"></i></div>
        <div><span class="stat-num">{{ events.length }}</span><span class="stat-lbl">All Events</span></div>
      </div>
      <div class="stat-card" [class.active]="statusFilter==='PUBLISHED'" (click)="statusFilter='PUBLISHED'; applyFilter()">
        <div class="stat-icon green"><i class="pi pi-globe"></i></div>
        <div><span class="stat-num">{{ publishedCount }}</span><span class="stat-lbl">Published</span></div>
      </div>
      <div class="stat-card" [class.active]="statusFilter==='DRAFT'" (click)="statusFilter='DRAFT'; applyFilter()">
        <div class="stat-icon amber"><i class="pi pi-file-edit"></i></div>
        <div><span class="stat-num">{{ draftCount }}</span><span class="stat-lbl">Draft</span></div>
      </div>
      <div class="stat-card" [class.active]="statusFilter==='CANCELLED'" (click)="statusFilter='CANCELLED'; applyFilter()">
        <div class="stat-icon danger"><i class="pi pi-ban"></i></div>
        <div><span class="stat-num">{{ cancelledCount }}</span><span class="stat-lbl">Cancelled</span></div>
      </div>
    </div>

    <div class="card table-card" style="padding:0; overflow:hidden;">
      <div class="tbl-header">
        <p-iconfield>
          <p-inputicon styleClass="pi pi-search" />
          <input pInputText type="text" placeholder="Search events or clubs…"
            [(ngModel)]="searchTerm" (ngModelChange)="applyFilter()" />
        </p-iconfield>
        <span class="count-badge">{{ filteredEvents.length }} events</span>
      </div>

      <p-table [value]="pagedEvents" styleClass="p-datatable-sm" [tableStyle]="{'min-width':'700px'}">
        <ng-template pTemplate="header">
          <tr>
            <th style="width:44px">#</th>
            <th>Event</th>
            <th>Club</th>
            <th>Date</th>
            <th style="text-align:center">Registrations</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </ng-template>
        <ng-template pTemplate="body" let-ev let-i="rowIndex">
          <tr>
            <td class="row-num">{{ (currentPage-1)*pageSize + i + 1 }}</td>
            <td>
              <div class="ev-name">{{ ev.title }}</div>
              <div class="ev-meta-sm">{{ ev.paid ? '₹' + ev.fee : 'Free' }} &middot; {{ ev.location || 'TBA' }}</div>
            </td>
            <td>
              <p-chip [label]="ev.club?.clubName || '—'" styleClass="club-chip"></p-chip>
            </td>
            <td class="date-cell">{{ formatDate(ev.eventDate) }}</td>
            <td style="text-align:center;font-weight:700;color:#f1f5f9">{{ ev.registrationCount ?? 0 }}</td>
            <td>
              <p-tag
                [value]="ev.status"
                [severity]="ev.status === 'PUBLISHED' ? 'success' : ev.status === 'DRAFT' ? 'warning' : 'danger'"
              ></p-tag>
            </td>
            <td>
              <div class="action-btns">
                <p-button *ngIf="ev.status === 'DRAFT'" label="Publish" icon="pi pi-send" size="small" severity="success"
                  [loading]="processingId === ev.eventId" (onClick)="publishEvent(ev.eventId)"></p-button>
                <p-button *ngIf="ev.status !== 'CANCELLED'" icon="pi pi-ban" size="small" severity="danger"
                  [text]="true" pTooltip="Cancel event" tooltipPosition="top"
                  [loading]="processingId === ev.eventId" (onClick)="cancelEvent(ev.eventId, ev.title)"></p-button>
              </div>
            </td>
          </tr>
        </ng-template>
        <ng-template pTemplate="emptymessage">
          <tr><td colspan="7" style="text-align:center;padding:40px;color:var(--n-400)">No events match your filter.</td></tr>
        </ng-template>
      </p-table>

      <div class="tbl-footer">
        <app-pagination [totalItems]="filteredEvents.length" [pageSize]="pageSize"
          [currentPage]="currentPage" (pageChange)="onPageChange($event)"></app-pagination>
      </div>
    </div>
  </ng-container>
</div>
  `,
  styles: [`
    .admin-events { min-height:100vh; padding:28px 32px; max-width:1260px; margin:0 auto; animation: pageFadeIn .3s cubic-bezier(.16,1,.3,1) both; }
    @keyframes pageFadeIn { from { opacity:0; transform:translateY(10px); } to { opacity:1; transform:translateY(0); } }
    .page-header { margin-bottom:24px; }
    .page-header h1 { font-size:24px; font-weight:800; color:#f1f5f9; letter-spacing:-.04em; }
    .page-header p  { font-size:13.5px; color:rgba(255,255,255,.38); margin-top:5px; }
    .stats-row { display:grid; grid-template-columns:repeat(4,1fr); gap:14px; margin-bottom:20px; }
    @media (max-width:640px) { .stats-row { grid-template-columns:repeat(2,1fr); } }
    .stat-card { background:rgba(255,255,255,.04); border:1.5px solid rgba(255,255,255,.08); border-radius:16px; padding:16px 18px; cursor:pointer; transition:all .25s cubic-bezier(.16,1,.3,1); display:flex; align-items:center; gap:12px; position:relative; overflow:hidden; }
    .stat-card:hover { border-color:rgba(255,255,255,.15); transform:translateY(-3px); box-shadow:0 12px 32px rgba(0,0,0,.4); }
    .stat-card.active { border-color:rgba(99,102,241,.4); background:rgba(99,102,241,.1); }
    .stat-card.active .stat-num { color:#a5b4fc; }
    .stat-icon { width:42px; height:42px; border-radius:13px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
    .stat-icon i { font-size:18px; }
    .stat-icon.brand  { background:rgba(99,102,241,.15); } .stat-icon.brand i  { color:#a5b4fc; }
    .stat-icon.green  { background:rgba(5,150,105,.15);  } .stat-icon.green i  { color:#6ee7b7; }
    .stat-icon.amber  { background:rgba(217,119,6,.15);  } .stat-icon.amber i  { color:#fcd34d; }
    .stat-icon.danger { background:rgba(239,68,68,.15);  } .stat-icon.danger i { color:#fca5a5; }
    .stat-num { display:block; font-size:22px; font-weight:900; color:#f1f5f9; letter-spacing:-.05em; line-height:1; transition:color .2s; }
    .stat-lbl { display:block; font-size:11.5px; color:rgba(255,255,255,.35); font-weight:500; margin-top:3px; }
    .card.table-card { background:rgba(255,255,255,.04); backdrop-filter:blur(20px); border:1px solid rgba(255,255,255,.08); border-radius:20px; box-shadow:0 8px 28px rgba(0,0,0,.4); }
    .tbl-header { display:flex; align-items:center; gap:16px; padding:16px 20px; border-bottom:1px solid rgba(255,255,255,.07); flex-wrap:wrap; }
    .count-badge { font-size:12.5px; color:rgba(255,255,255,.35); font-weight:500; }
    .ev-name { font-size:14px; font-weight:600; color:#f1f5f9; }
    .ev-meta-sm { font-size:12px; color:rgba(255,255,255,.38); margin-top:2px; }
    ::ng-deep .club-chip { font-size:11.5px !important; padding:3px 10px !important; background:rgba(99,102,241,.15) !important; color:#a5b4fc !important; border:none !important; }
    .date-cell { font-size:12.5px; color:rgba(255,255,255,.38); }
    .row-num { font-size:12px; color:rgba(255,255,255,.25); }
    .action-btns { display:flex; gap:6px; align-items:center; }
    .tbl-footer { padding:12px 20px; border-top:1px solid rgba(255,255,255,.07); }
    ::ng-deep .admin-events .p-datatable .p-datatable-thead > tr > th { background:rgba(255,255,255,.03) !important; border-color:rgba(255,255,255,.07) !important; color:rgba(255,255,255,.45) !important; font-size:11px !important; font-weight:800 !important; letter-spacing:.07em !important; text-transform:uppercase !important; padding:11px 14px !important; }
    ::ng-deep .admin-events .p-datatable .p-datatable-tbody > tr > td { background:transparent !important; border-color:rgba(255,255,255,.05) !important; color:rgba(255,255,255,.75) !important; padding:12px 14px !important; }
    ::ng-deep .admin-events .p-datatable .p-datatable-tbody > tr:hover > td { background:rgba(255,255,255,.04) !important; }
    ::ng-deep .admin-events .p-iconfield .p-inputtext { background:rgba(255,255,255,.07) !important; border:1.5px solid rgba(255,255,255,.1) !important; border-radius:11px !important; color:#e2e8f0 !important; font-size:13.5px !important; padding:10px 14px 10px 40px !important; min-width:280px; }
    ::ng-deep .admin-events .p-iconfield .p-inputtext::placeholder { color:rgba(255,255,255,.28) !important; }
    ::ng-deep .admin-events .p-iconfield .p-inputtext:focus { background:rgba(255,255,255,.1) !important; border-color:rgba(99,102,241,.55) !important; box-shadow:0 0 0 3px rgba(99,102,241,.12) !important; }
    ::ng-deep .admin-events .p-iconfield .p-inputicon { color:rgba(255,255,255,.3) !important; }
  `]
})
export class AdminEventsComponent implements OnInit {
  events: any[] = [];
  filteredEvents: any[] = [];
  loading = true;
  searchTerm = '';
  statusFilter = 'ALL';
  processingId: number | null = null;
  currentPage = 1;
  readonly pageSize = 15;

  constructor(private adminService: AdminService, private toastr: ToastrService, private cdr: ChangeDetectorRef) {}

  ngOnInit(): void { this.loadEvents(); }

  loadEvents() {
    this.loading = true;
    this.adminService.getAllEvents().subscribe({
      next: (data) => { this.events = data; this.applyFilter(); this.loading = false; this.cdr.detectChanges(); },
      error: () => { this.toastr.error('Failed to load events'); this.loading = false; this.cdr.detectChanges(); }
    });
  }

  applyFilter() {
    this.currentPage = 1;
    let result = this.events;
    if (this.statusFilter !== 'ALL') result = result.filter(e => e.status === this.statusFilter);
    if (this.searchTerm.trim()) {
      const term = this.searchTerm.toLowerCase();
      result = result.filter(e => e.title?.toLowerCase().includes(term) || e.club?.clubName?.toLowerCase().includes(term));
    }
    this.filteredEvents = result;
  }

  publishEvent(eventId: number) {
    this.processingId = eventId;
    this.adminService.publishEvent(eventId).subscribe({
      next: () => { const ev = this.events.find(e => e.eventId === eventId); if (ev) ev.status = 'PUBLISHED'; this.applyFilter(); this.processingId = null; this.toastr.success('Event published'); },
      error: () => { this.processingId = null; this.toastr.error('Failed to publish'); }
    });
  }

  cancelEvent(eventId: number, title: string) {
    if (!confirm(`Cancel event "${title}"? This cannot be undone.`)) return;
    this.processingId = eventId;
    this.adminService.cancelEvent(eventId).subscribe({
      next: () => { const ev = this.events.find(e => e.eventId === eventId); if (ev) ev.status = 'CANCELLED'; this.applyFilter(); this.processingId = null; this.toastr.warning('Event cancelled'); },
      error: () => { this.processingId = null; this.toastr.error('Failed to cancel'); }
    });
  }

  get pagedEvents() { const start = (this.currentPage - 1) * this.pageSize; return this.filteredEvents.slice(start, start + this.pageSize); }
  onPageChange(page: number) { this.currentPage = page; }
  get publishedCount() { return this.events.filter(e => e.status === 'PUBLISHED').length; }
  get draftCount() { return this.events.filter(e => e.status === 'DRAFT').length; }
  get cancelledCount() { return this.events.filter(e => e.status === 'CANCELLED').length; }
  formatDate(date: string): string { if (!date) return 'TBA'; return new Date(date).toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' }); }
}
